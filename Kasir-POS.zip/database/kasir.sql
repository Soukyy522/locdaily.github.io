-- ========================================================
-- DATABASE STRUCTURE FOR KASIR SAFANA (kasir.sql)
-- ========================================================

CREATE DATABASE IF NOT EXISTS kasir;
USE kasir;

-- 1. TABEL USER (AUTENTIKASI LOGIN)
DROP TABLE IF EXISTS user;
CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Akun Default Kasir
INSERT INTO user (username, password) VALUES
('safana', 'A1234567');


-- 2. TABEL BARANG (STOK MENGGUNAKAN DECIMAL UNTUK DESIMAL/KILOAN)
DROP TABLE IF EXISTS barang;
CREATE TABLE barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    stok DECIMAL(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sampel Data Barang Awal
INSERT INTO barang (kode, nama_barang, harga, stok) VALUES
('BRG001', 'Telur Biasa', 27000, 50.00),
('BRG002', 'Telur Omega', 29000, 40.00),
('BRG003', 'Tepung Terigu', 12000, 25.50),
('BRG004', 'Minyak Goreng 1L', 20500, 30.00);


-- 3. TABEL TRANSAKSI (MENGGUNAKAN DATETIME AGAR TERCATAT TANGGAL & JAM)
DROP TABLE IF EXISTS transaksi;
CREATE TABLE transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATETIME NOT NULL,
    total INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 4. TABEL DETAIL TRANSAKSI (PEMBELIAN DETAIL ITEM)
DROP TABLE IF EXISTS detail_transaksi;
CREATE TABLE detail_transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_transaksi INT NOT NULL,
    id_barang INT NOT NULL,
    jumlah DECIMAL(10,2) NOT NULL,
    subtotal INT NOT NULL,
    FOREIGN KEY (id_transaksi) REFERENCES transaksi(id) ON DELETE CASCADE,
    FOREIGN KEY (id_barang) REFERENCES barang(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;