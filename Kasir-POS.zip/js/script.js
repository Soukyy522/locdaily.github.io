
function login(){

let user =
document.getElementById("username").value;


let pass =
document.getElementById("password").value;


if(user=="admin" && pass=="12345"){

alert("Login berhasil");

location.href="dashboard.html";

}

else{

alert("Username atau password salah");

}

}



let total=0;


function tambah(){

let nama=
document.getElementById("namaBarang").value;


let harga=
Number(document.getElementById("harga").value);


let jumlah=
Number(document.getElementById("jumlah").value);


let hasil=harga*jumlah;


total+=hasil;


let tabel=
document.getElementById("table");


let row=tabel.insertRow();


row.insertCell(0).innerHTML=nama;

row.insertCell(1).innerHTML=harga;

row.insertCell(2).innerHTML=jumlah;

row.insertCell(3).innerHTML=hasil;


document.getElementById("total").innerHTML=
"Total : Rp "+total;


}