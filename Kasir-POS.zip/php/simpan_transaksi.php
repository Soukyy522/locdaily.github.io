<?php
session_start();

// Cek status login
if (!isset($_SESSION['login'])) {
    header("location:login.php");
    exit;
}

include "config/koneksi.php";

// Pastikan data dikirim melalui metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Ambil dan amankan data dari form kasir
    $id_barang = mysqli_real_escape_string($conn, $_POST['barang'] ?? '');
    
    // Menggunakan floatval agar mendukung pembelian kiloan/desimal (misal: 0.5 kg)
    $jumlah = isset($_POST['jumlah']) ? floatval($_POST['jumlah']) : 0;

    // Validasi input awal
    if (empty($id_barang) || $jumlah <= 0) {
        echo "<script>
                alert('Data transaksi tidak valid!');
                window.location.href='kasir.php';
              </script>";
        exit;
    }

    // Ambil data barang dari database
    $query_barang = mysqli_query($conn, "SELECT * FROM barang WHERE id='$id_barang'");
    $b = mysqli_fetch_array($query_barang);

    if (!$b) {
        echo "<script>
                alert('Barang tidak ditemukan!');
                window.location.href='kasir.php';
              </script>";
        exit;
    }

    // Cek apakah stok mencukupi
    if ($b['stok'] < $jumlah) {
        echo "<script>
                alert('Stok tidak mencukupi! Stok tersisa: {$b['stok']}');
                window.location.href='kasir.php';
              </script>";
        exit;
    }

    // Hitung total harga transaksi (dibulatkan ke integer)
    $total = round($b['harga'] * $jumlah);

    // 1. Simpan transaksi ke tabel 'transaksi' (Menggunakan NOW() agar tercatat tanggal & jam)
    $insert_transaksi = mysqli_query($conn, "INSERT INTO transaksi (id, tanggal, total) VALUES (NULL, NOW(), '$total')");

    // 2. Potong/kurangi stok barang
    $update_stok = mysqli_query($conn, "UPDATE barang SET stok = stok - $jumlah WHERE id='$id_barang'");

    // Cek keberhasilan transaksi
    if ($insert_transaksi && $update_stok) {
        echo "<script>
                alert('Transaksi Berhasil!');
                window.location.href='kasir.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal memproses transaksi!');
                window.location.href='kasir.php';
              </script>";
    }

} else {
    // Jika file diakses langsung tanpa kirim form/POST, kembalikan ke kasir.php
    header("location:kasir.php");
    exit;
}
?>