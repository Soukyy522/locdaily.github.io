<?php
include "config/koneksi.php";

// Ambil data barang dari database
$data = mysqli_query($conn, "SELECT * FROM barang ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang - Safana Kasir</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f6f9; min-height: 100vh; color: #334155; }

        .app-layout { display: flex; flex-direction: column; min-height: 100vh; }

        /* Navigasi / Menu */
        .nav-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; display: flex; justify-content: space-around; padding: 10px 0; border-top: 1px solid #e2e8f0; z-index: 99; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); }
        .nav-item { text-decoration: none; color: #94a3b8; font-size: 0.75rem; font-weight: 600; display: flex; flex-direction: column; align-items: center; gap: 3px; }
        .nav-item span { font-size: 1.3rem; }
        .nav-item.active { color: #0d2240; font-weight: 700; }

        .main-content { padding: 15px; padding-bottom: 80px; flex: 1; }

        .header-app { background: #0d2240; color: white; padding: 15px 20px; border-radius: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header-app h2 { font-size: 1.2rem; font-weight: 700; }

        /* Tombol Tambah Barang */
        .btn-tambah { display: inline-block; background: #0284c7; color: white; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.85rem; text-decoration: none; margin-bottom: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: background 0.2s; }
        .btn-tambah:hover { background: #0369a1; }

        /* Tabel Styling Modern */
        .table-responsive { background: white; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8fafc; color: #475569; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
        td { padding: 14px 16px; border-bottom: 1px dashed #e2e8f0; font-size: 0.85rem; color: #0d2240; }
        tr:last-child td { border-bottom: none; }

        .btn-hapus { background: #fee2e2; color: #ef4444; text-decoration: none; padding: 6px 12px; border-radius: 8px; font-weight: 600; font-size: 0.75rem; display: inline-block; transition: background 0.2s; }
        .btn-hapus:hover { background: #fca5a5; }

        /* Responsive Tampilan Desktop */
        @media (min-width: 768px) {
            .app-layout { flex-direction: row; }
            .nav-bar { position: relative; width: 250px; flex-direction: column; justify-content: flex-start; padding: 30px 15px; border-top: none; border-right: 1px solid #e2e8f0; gap: 10px; background: #0d2240; }
            .nav-item { flex-direction: row; gap: 15px; padding: 12px 18px; border-radius: 12px; color: #94a3b8; font-size: 0.95rem; width: 100%; justify-content: flex-start; }
            .nav-item.active { background: #ffc107; color: #0d2240; }
            .main-content { padding: 30px; padding-bottom: 30px; }
        }
    </style>
</head>
<body>

    <div class="app-layout">
        <!-- Sidebar / Bottom Navigation -->
        <div class="nav-bar">
            <a href="dashboard.php" class="nav-item"><span>📊</span> Dashboard</a>
            <a href="kasir.php" class="nav-item"><span>💵</span> Kasir</a>
            <a href="barang.php" class="nav-item active"><span>📦</span> Barang</a>
            <a href="laporan.php" class="nav-item"><span>📋</span> Laporan</a>
        </div>

        <div class="main-content">
            <div class="header-app">
                <h2>Data Barang</h2>
                <span style="font-size: 1.2rem;">📦</span>
            </div>

            <!-- Tombol Tambah Barang -->
            <a href="tambah_barang.php" class="btn-tambah">+ TAMBAH BARANG</a>

            <!-- Tabel Data Barang -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th style="text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Cek jika data tersedia di database
                        if(mysqli_num_rows($data) > 0) {
                            while($d = mysqli_fetch_array($data)){ 
                        ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($d['kode']); ?></strong></td>
                                <td><?= htmlspecialchars($d['nama_barang']); ?></td>
                                <td>Rp <?= number_format($d['harga'], 0, ',', '.'); ?></td>
                                <td><?= htmlspecialchars($d['stok']); ?></td>
                                <td style="text-align: center;">
                                    <a href="hapus_barang.php?id=<?= $d['id']; ?>" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus barang ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else { 
                        ?>
                            <tr>
                                <td colspan="5" style="text-align:center; color:#94a3b8; padding:20px;">Belum ada data barang.</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>