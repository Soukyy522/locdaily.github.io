<?php
session_start();

// Cek status login
if (!isset($_SESSION['login'])) {
    header("location:login.php");
    exit;
}

include "config/koneksi.php";

// Ambil data barang dari database MySQL
$data = mysqli_query($conn, "SELECT * FROM barang ORDER BY nama_barang ASC");
$arr_barang = [];
while ($b = mysqli_fetch_assoc($data)) {
    $arr_barang[] = $b;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir - Safana POS</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f6f9; min-height: 100vh; color: #334155; }

        .app-layout { display: flex; flex-direction: column; min-height: 100vh; }

        /* Navigasi / Menu */
        .nav-bar { 
            position: fixed; bottom: 0; left: 0; width: 100%; background: white; 
            display: flex; justify-content: space-around; padding: 10px 0; 
            border-top: 1px solid #e2e8f0; z-index: 99; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); 
        }
        .nav-item { text-decoration: none; color: #94a3b8; font-size: 0.75rem; font-weight: 600; display: flex; flex-direction: column; align-items: center; gap: 3px; }
        .nav-item span { font-size: 1.3rem; }
        .nav-item.active { color: #0d2240; font-weight: 700; }

        .main-content { padding: 15px; padding-bottom: 85px; flex: 1; }

        .header-app { background: #0d2240; color: white; padding: 15px 20px; border-radius: 16px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; }
        .header-app h2 { font-size: 1.1rem; font-weight: 700; }

        /* Grid Layout Kasir */
        .kasir-grid { display: grid; grid-template-columns: 1fr; gap: 12px; max-width: 900px; margin: 0 auto; }

        .box-form, .cart-box, .pay-box { 
            background: white; padding: 15px; border-radius: 16px; 
            border: 1px solid #e2e8f0; box-shadow: 0 4px 6px rgba(0,0,0,0.02); 
        }

        label { font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase; display: block; margin-bottom: 6px; }
        select, input[type="number"], input[type="text"] { 
            width: 100%; padding: 10px 12px; border: 1.5px solid #e2e8f0; 
            border-radius: 10px; font-size: 0.9rem; outline: none; background: #f8fafc; color: #334155; 
        }
        select:focus, input:focus { border-color: #0284c7; background: #fff; }

        .row { display: flex; gap: 8px; margin-bottom: 10px; }
        .row .b-1 { flex: 1.8; }
        .row .b-2 { flex: 1; }

        .qty-quick { display: flex; gap: 4px; margin-bottom: 10px; }
        .qty-quick button { 
            flex: 1; padding: 6px 2px; background: #f1f5f9; color: #334155; 
            border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.7rem; font-weight: 600; cursor: pointer; 
        }
        .qty-quick button:hover { background: #e2e8f0; }

        .btn-add { 
            width: 100%; padding: 10px; background: #0d2240; color: white; 
            border: none; border-radius: 8px; font-size: 0.85rem; font-weight: 600; cursor: pointer; 
        }
        .btn-add:hover { background: #1a365d; }

        /* Keranjang List */
        .cart-list { max-height: 200px; overflow-y: auto; margin-bottom: 10px; }
        .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px dashed #e2e8f0; font-size: 0.82rem; gap: 8px; }
        .cart-item-title { flex: 1; line-height: 1.2; }
        .btn-del { background: #fee2e2; color: #ef4444; border: none; padding: 4px 8px; border-radius: 6px; font-weight: 700; cursor: pointer; }
        .btn-del:hover { background: #fca5a5; }

        .total-box { background: #0d2240; color: white; padding: 12px; border-radius: 12px; text-align: center; margin-bottom: 10px; }
        .total-box h3 { font-size: 1.5rem; color: #ffc107; font-weight: 700; }

        .change-preview-box { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 8px 12px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; font-size: 0.8rem; }
        .change-preview-box strong { color: #15803d; font-size: 0.95rem; }

        .nominals { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-bottom: 12px; }
        .nominals button { padding: 8px 2px; background: #fff; color: #334155; border: 1px solid #cbd5e1; border-radius: 6px; font-weight: 600; font-size: 0.75rem; cursor: pointer; }
        .nominals button:hover { background: #f1f5f9; }
        .btn-uang-pas { background: #dcfce7 !important; border-color: #86efac !important; color: #15803d !important; }

        .btn-bayar { width: 100%; padding: 12px; background: #ffc107; color: #0d2240; border: none; border-radius: 10px; font-size: 0.95rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 10px rgba(255,193,7,0.3); }
        .btn-bayar:hover { background: #e0a800; }

        /* Responsive Desktop */
        @media (min-width: 768px) {
            .app-layout { flex-direction: row; }
            .nav-bar { position: relative; width: 250px; flex-direction: column; justify-content: flex-start; padding: 30px 15px; border-top: none; border-right: 1px solid #e2e8f0; gap: 10px; background: #0d2240; }
            .nav-item { flex-direction: row; gap: 15px; padding: 12px 18px; border-radius: 12px; color: #94a3b8; font-size: 0.95rem; width: 100%; justify-content: flex-start; }
            .nav-item.active { background: #ffc107; color: #0d2240; }
            .main-content { padding: 30px; }
            .kasir-grid { grid-template-columns: 1.2fr 1fr; align-items: start; }
        }
    </style>
</head>
<body>

    <div class="app-layout">
        <!-- Sidebar Navigation -->
        <div class="nav-bar">
            <a href="dashboard.php" class="nav-item"><span>📊</span> Dashboard</a>
            <a href="kasir.php" class="nav-item active"><span>💵</span> Kasir</a>
            <a href="barang.php" class="nav-item"><span>📦</span> Barang</a>
            <a href="laporan.php" class="nav-item"><span>📋</span> Laporan</a>
        </div>

        <div class="main-content">
            <div class="header-app">
                <h2>Transaksi Kasir - Safana POS</h2>
                <span style="font-size: 1.2rem;">💵</span>
            </div>

            <div class="kasir-grid">
                <!-- Kolom Kiri: Pilih Barang & Keranjang -->
                <div>
                    <div class="box-form">
                        <div class="row">
                            <div class="b-1">
                                <label>Pilih Barang</label>
                                <select id="pilihBarang">
                                    <option value="" data-harga="0" data-satuan="Pcs">-- Pilih Barang --</option>
                                    <?php foreach ($arr_barang as $b) { ?>
                                        <option value="<?= htmlspecialchars($b['nama_barang']) ?>" 
                                                data-harga="<?= $b['harga'] ?>" 
                                                data-satuan="<?= isset($b['satuan']) ? $b['satuan'] : 'Pcs' ?>">
                                            <?= htmlspecialchars($b['nama_barang']) ?> - Rp <?= number_format($b['harga'], 0, ',', '.') ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="b-2">
                                <label>Jumlah</label>
                                <input type="number" id="jumlahBarang" value="1" step="any" min="0.01">
                            </div>
                        </div>

                        <div class="qty-quick">
                            <button type="button" onclick="setQty(0.25)">¼ (0.25)</button>
                            <button type="button" onclick="setQty(0.5)">½ (0.5)</button>
                            <button type="button" onclick="setQty(1)">1</button>
                            <button type="button" onclick="setQty(2)">2</button>
                        </div>

                        <button type="button" class="btn-add" onclick="tambahKeKeranjang()">+ Tambah ke Keranjang</button>
                    </div>

                    <div class="cart-box" style="margin-top: 12px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label style="margin-bottom:0;">Keranjang Belanja</label>
                            <button onclick="kosongkanKeranjang()" style="background:none; border:none; color:#ef4444; font-size:0.7rem; font-weight:600; cursor:pointer;">[Kosongkan]</button>
                        </div>
                        <div class="cart-list" id="cartList">
                            <p style="text-align:center; color:#94a3b8; font-size:0.85rem; padding:15px;">Keranjang kosong</p>
                        </div>
                    </div>
                </div>

                <!-- Kolom Kanan: Pembayaran & Total -->
                <div class="pay-box">
                    <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: #64748b; margin-bottom: 6px;">
                        <span>Subtotal:</span>
                        <strong id="subtotalText">Rp 0</strong>
                    </div>

                    <div class="total-box">
                        <div style="font-size: 0.75rem; text-transform: uppercase;">Total Tagihan</div>
                        <h3>Rp <span id="totalText">0</span></h3>
                    </div>

                    <label>Uang Diterima (Tunai)</label>
                    <input type="text" id="uangBayar" inputmode="numeric" placeholder="Ketik nominal..." oninput="formatUangInput(this)" style="margin-bottom: 8px;">

                    <div class="change-preview-box">
                        <span>Estimasi Kembalian:</span>
                        <strong>Rp <span id="previewKembaliText">0</span></strong>
                    </div>

                    <div class="nominals">
                        <button type="button" class="btn-uang-pas" onclick="setUangPas()">Uang Pas</button>
                        <button type="button" onclick="tambahUang(5000)">+5rb</button>
                        <button type="button" onclick="tambahUang(10000)">+10rb</button>
                        <button type="button" onclick="tambahUang(20000)">+20rb</button>
                        <button type="button" onclick="tambahUang(50000)">+50rb</button>
                        <button type="button" onclick="tambahUang(100000)">+100rb</button>
                    </div>

                    <button type="button" class="btn-bayar" onclick="prosesBayar()">💵 PROSES PEMBAYARAN</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let keranjang = [];
        let subtotalBelanja = 0;
        let uangTunai = 0;

        function setQty(val) {
            document.getElementById("jumlahBarang").value = val;
        }

        function tambahKeKeranjang() {
            let select = document.getElementById("pilihBarang");
            let selectedOpt = select.options[select.selectedIndex];
            let namaBarang = select.value;
            
            if (!namaBarang) {
                alert("Silakan pilih barang terlebih dahulu!");
                return;
            }

            let harga = Number(selectedOpt.getAttribute("data-harga")) || 0;
            let satuan = selectedOpt.getAttribute("data-satuan") || 'Pcs';
            let qty = parseFloat(document.getElementById("jumlahBarang").value) || 1;

            if (qty <= 0) {
                alert("Jumlah harus lebih besar dari 0!");
                return;
            }

            let existing = keranjang.find(item => item.nama === namaBarang);
            if (existing) {
                existing.qty += qty;
                existing.subtotal = existing.qty * existing.harga;
            } else {
                keranjang.push({
                    nama: namaBarang,
                    harga: harga,
                    qty: qty,
                    satuan: satuan,
                    subtotal: qty * harga
                });
            }

            // Reset input
            select.selectedIndex = 0;
            document.getElementById("jumlahBarang").value = "1";
            renderKeranjang();
        }

        function renderKeranjang() {
            let container = document.getElementById("cartList");
            container.innerHTML = "";

            if (keranjang.length === 0) {
                container.innerHTML = `<p style="text-align:center; color:#94a3b8; font-size:0.85rem; padding:15px;">Keranjang kosong</p>`;
                subtotalBelanja = 0;
                hitungTotal();
                return;
            }

            subtotalBelanja = 0;
            keranjang.forEach((item, index) => {
                subtotalBelanja += item.subtotal;
                let row = document.createElement("div");
                row.className = "cart-item";
                row.innerHTML = `
                    <div class="cart-item-title">
                        <strong>${item.nama}</strong><br>
                        <small style="color:#64748b;">${item.qty} ${item.satuan} × Rp ${item.harga.toLocaleString('id-ID')}</small>
                    </div>
                    <div style="font-weight:700; text-align:right;">
                        Rp ${item.subtotal.toLocaleString('id-ID')}
                    </div>
                    <button class="btn-del" onclick="hapusItem(${index})">✕</button>
                `;
                container.appendChild(row);
            });

            hitungTotal();
        }

        function hapusItem(index) {
            keranjang.splice(index, 1);
            renderKeranjang();
        }

        function kosongkanKeranjang() {
            keranjang = [];
            renderKeranjang();
        }

        function hitungTotal() {
            document.getElementById("subtotalText").innerText = `Rp ${subtotalBelanja.toLocaleString('id-ID')}`;
            document.getElementById("totalText").innerText = subtotalBelanja.toLocaleString('id-ID');
            hitungKembalian();
        }

        function formatUangInput(el) {
            let raw = el.value.replace(/[^0-9]/g, "");
            uangTunai = Number(raw) || 0;
            el.value = raw ? Number(raw).toLocaleString('id-ID') : "";
            hitungKembalian();
        }

        function setUangPas() {
            uangTunai = subtotalBelanja;
            document.getElementById("uangBayar").value = uangTunai ? uangTunai.toLocaleString('id-ID') : "0";
            hitungKembalian();
        }

        function tambahUang(nominal) {
            uangTunai += nominal;
            document.getElementById("uangBayar").value = uangTunai.toLocaleString('id-ID');
            hitungKembalian();
        }

        function hitungKembalian() {
            let kembali = uangTunai - subtotalBelanja;
            let elKembali = document.getElementById("previewKembaliText");
            if (kembali >= 0) {
                elKembali.innerText = kembali.toLocaleString('id-ID');
            } else {
                elKembali.innerText = "0 (Kurang)";
            }
        }

        function prosesBayar() {
            if (keranjang.length === 0) {
                alert("Keranjang masih kosong!");
                return;
            }
            if (uangTunai < subtotalBelanja) {
                alert("Uang pembayaran kurang dari total tagihan!");
                return;
            }

            let kembalian = uangTunai - subtotalBelanja;
            alert(`Transaksi Berhasil!\nKembalian: Rp ${kembalian.toLocaleString('id-ID')}`);

            // Reset transaksi
            keranjang = [];
            uangTunai = 0;
            document.getElementById("uangBayar").value = "";
            renderKeranjang();
        }
    </script>
</body>
</html>