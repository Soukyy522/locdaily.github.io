<?php
session_start();

// Cek status login (opsional)
if (!isset($_SESSION['login'])) {
    header("location:login.php");
    exit;
}

include "config/koneksi.php";

$error = "";

// Proses simpan data saat tombol diklik
if (isset($_POST['simpan'])) {
    $kode  = mysqli_real_escape_string($conn, $_POST['kode']);
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = floatval($_POST['harga']);
    $stok  = floatval($_POST['stok']); // Menggunakan floatval agar mendukung stok desimal/kiloan

    // Validasi input sederhana
    if (empty($kode) || empty($nama) || $harga <= 0) {
        $error = "Harap isi Kode, Nama Barang, dan Harga dengan benar!";
    } else {
        // Query Simpan Barang ke Database
        $query = mysqli_query($conn, "INSERT INTO barang (id, kode, nama_barang, harga, stok) VALUES (NULL, '$kode', '$nama', '$harga', '$stok')");

        if ($query) {
            header("location:barang.php");
            exit;
        } else {
            $error = "Gagal menyimpan data barang: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang - Safana Kasir</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f6f9; min-height: 100vh; }

        .app-layout { display: flex; flex-direction: column; min-height: 100vh; }

        /* Navigasi / Menu */
        .nav-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; display: flex; justify-content: space-around; padding: 10px 0; border-top: 1px solid #e2e8f0; z-index: 99; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); }
        .nav-item { text-decoration: none; color: #94a3b8; font-size: 0.75rem; font-weight: 600; display: flex; flex-direction: column; align-items: center; gap: 3px; }
        .nav-item span { font-size: 1.3rem; }
        .nav-item.active { color: #0d2240; font-weight: 700; }

        .main-content { padding: 15px; padding-bottom: 80px; flex: 1; }

        .header-app { background: #0d2240; color: white; padding: 15px 20px; border-radius: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header-app h2 { font-size: 1.2rem; font-weight: 700; }

        /* Form Container */
        .card-form { background: white; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; max-width: 500px; margin: 0 auto; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }

        .alert-error { background: #fee2e2; color: #ef4444; padding: 12px; border-radius: 10px; font-size: 0.85rem; font-weight: 600; margin-bottom: 15px; border: 1px solid #fca5a5; }

        .form-group { margin-bottom: 15px; }
        label { font-size: 0.75rem; font-weight: 700; color: #475569; text-transform: uppercase; display: block; margin-bottom: 6px; }
        input { width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 0.95rem; outline: none; background: #f8fafc; transition: border-color 0.2s; }
        input:focus { border-color: #0d2240; background: #fff; }

        .btn-simpan { width: 100%; padding: 14px; background: #ffc107; color: #0d2240; border: none; border-radius: 10px; font-weight: 700; font-size: 0.95rem; cursor: pointer; margin-top: 10px; box-shadow: 0 4px 10px rgba(255,193,7,0.3); }
        .btn-simpan:hover { background: #e0a800; }

        .btn-kembali { display: block; text-align: center; color: #64748b; text-decoration: none; font-size: 0.85rem; font-weight: 600; margin-top: 15px; }
        .btn-kembali:hover { color: #0d2240; }

        /* Responsive Desktop */
        @media (min-width: 768px) {
            .app-layout { flex-direction: row; }
            .nav-bar { position: relative; width: 250px; flex-direction: column; justify-content: flex-start; padding: 30px 15px; border-top: none; border-right: 1px solid #e2e8f0; gap: 10px; background: #0d2240; }
            .nav-item { flex-direction: row; gap: 15px; padding: 12px 18px; border-radius: 12px; color: #94a3b8; font-size: 0.95rem; width: 100%; justify-content: flex-start; }
            .nav-item.active { background: #ffc107; color: #0d2240; }
            .main-content { padding: 30px; padding-bottom: 30px; }
        }
    </style>
</head>
<body>

    <div class="app-layout">
        <!-- Sidebar Navigation -->
        <div class="nav-bar">
            <a href="dashboard.php" class="nav-item"><span>📊</span> Dashboard</a>
            <a href="kasir.php" class="nav-item"><span>💵</span> Kasir</a>
            <a href="barang.php" class="nav-item active"><span>📦</span> Barang</a>
            <a href="laporan.php" class="nav-item"><span>📋</span> Laporan</a>
        </div>

        <div class="main-content">
            <div class="header-app">
                <h2>Tambah Barang Baru</h2>
                <span style="font-size: 1.2rem;">📦</span>
            </div>

            <div class="card-form">
                <?php if (!empty($error)) { ?>
                    <div class="alert-error"><?=$error?></div>
                <?php } ?>

                <form method="post">
                    <div class="form-group">
                        <label>Kode Barang</label>
                        <input name="kode" type="text" placeholder="Contoh: BRG001" required autofocus>
                    </div>

                    <div class="form-group">
                        <label>Nama Barang</label>
                        <input name="nama" type="text" placeholder="Contoh: Telur Itik" required>
                    </div>

                    <div class="form-group">
                        <label>Harga Barang (Rp)</label>
                        <input name="harga" type="number" step="any" placeholder="Contoh: 27000" required>
                    </div>

                    <div class="form-group">
                        <label>Stok Barang / Kiloan</label>
                        <input name="stok" type="number" step="any" placeholder="Contoh: 50 atau 12.5" required>
                    </div>

                    <button name="simpan" type="submit" class="btn-simpan">+ SIMPAN BARANG</button>
                    <a href="barang.php" class="btn-kembali">← Batal & Kembali</a>
                </form>
            </div>
        </div>
    </div>

</body>
</html>