<?php

$server   = "localhost";
$user     = "root";
$password = "";
$db       = "kasir";

// Mengkoneksikan ke database MySQL
$conn = mysqli_connect($server, $user, $password, $db);

// Cek status koneksi database
if (!$conn) {
    die("Database gagal terhubung: " . mysqli_connect_error());
}

// Menetapkan karakter encoding ke UTF-8 (agar support simbol/teks khusus)
mysqli_set_charset($conn, "utf8");

?>