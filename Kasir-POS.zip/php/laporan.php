<?php
session_start();

// Cek status login (opsional, hapus 3 baris ini jika belum menggunakan login)
if (!isset($_SESSION['login'])) {
    header("location:login.php");
    exit;
}

include "config/koneksi.php";

// Ambil data transaksi dari database MySQL (Diurutkan dari transaksi terbaru)
$data = mysqli_query($conn, "SELECT * FROM transaksi ORDER BY id DESC");

// Hitung Ringkasan Total Pendapatan
$total_pendapatan = 0;
$total_transaksi  = mysqli_num_rows($data);

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan - Safana Kasir</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #f4f6f9; min-height: 100vh; }

        .app-layout { display: flex; flex-direction: column; min-height: 100vh; }

        /* Navigasi / Menu */
        .nav-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; display: flex; justify-content: space-around; padding: 10px 0; border-top: 1px solid #e2e8f0; z-index: 99; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); }
        .nav-item { text-decoration: none; color: #94a3b8; font-size: 0.75rem; font-weight: 600; display: flex; flex-direction: column; align-items: center; gap: 3px; }
        .nav-item span { font-size: 1.3rem; }
        .nav-item.active { color: #0d2240; font-weight: 700; }

        .main-content { padding: 15px; padding-bottom: 80px; flex: 1; }

        .header-app { background: #0d2240; color: white; padding: 15px 20px; border-radius: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header-app h2 { font-size: 1.2rem; font-weight: 700; }

        /* Card Summary / Ringkasan Penjualan */
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .summary-card { background: white; padding: 18px; border-radius: 16px; border: 1px solid #e2e8f0; }
        .summary-card p { font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase; }
        .summary-card h3 { font-size: 1.4rem; font-weight: 700; color: #0d2240; margin-top: 4px; }
        .summary-card.highlight h3 { color: #10b981; }

        /* Tabel Styling Modern */
        .table-responsive { background: white; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f8fafc; color: #475569; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; padding: 14px 16px; border-bottom: 1px solid #e2e8f0; }
        td { padding: 14px 16px; border-bottom: 1px dashed #e2e8f0; font-size: 0.85rem; color: #0d2240; }
        tr:last-child td { border-bottom: none; }

        /* Responsive Tampilan Desktop */
        @media (min-width: 768px) {
            .app-layout { flex-direction: row; }
            .nav-bar { position: relative; width: 250px; flex-direction: column; justify-content: flex-start; padding: 30px 15px; border-top: none; border-right: 1px solid #e2e8f0; gap: 10px; background: #0d2240; }
            .nav-item { flex-direction: row; gap: 15px; padding: 12px 18px; border-radius: 12px; color: #94a3b8; font-size: 0.95rem; width: 100%; justify-content: flex-start; }
            .nav-item.active { background: #ffc107; color: #0d2240; }
            .main-content { padding: 30px; padding-bottom: 30px; }
        }
    </style>
</head>
<body>

    <div class="app-layout">
        <!-- Sidebar Navigation -->
        <div class="nav-bar">
            <a href="dashboard.php" class="nav-item"><span>📊</span> Dashboard</a>
            <a href="kasir.php" class="nav-item"><span>💵</span> Kasir</a>
            <a href="barang.php" class="nav-item"><span>📦</span> Barang</a>
            <a href="laporan.php" class="nav-item active"><span>📋</span> Laporan</a>
        </div>

        <div class="main-content">
            <div class="header-app">
                <h2>Laporan Penjualan</h2>
                <span style="font-size: 1.2rem;">📋</span>
            </div>

            <!-- Tabel Data Laporan Transaksi -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 60px;">No</th>
                            <th>Tanggal & Waktu</th>
                            <th style="text-align: right;">Total Transaksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($total_transaksi > 0) {
                            $no = 1;
                            while ($d = mysqli_fetch_array($data)) { 
                                // Menjumlahkan akumulasi total omset
                                $total_pendapatan += $d['total'];
                        ?>
                            <tr>
                                <td><strong><?=$no++?></strong></td>
                                <td><?=$d['tanggal']?></td>
                                <td style="text-align: right; font-weight: 600; color: #10b981;">
                                    Rp <?=number_format($d['total'], 0, ',', '.')?>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else { 
                        ?>
                            <tr>
                                <td colspan="3" style="text-align:center; color:#94a3b8; padding:20px;">
                                    Belum ada transaksi penjualan recorded.
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>