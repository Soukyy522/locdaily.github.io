<?php
session_start();

// Jika pengguna sudah login, langsung arahkan ke dashboard
if (isset($_SESSION['login'])) {
    header("location:dashboard.php");
    exit;
}

include "config/koneksi.php";

$error = "";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Query cek username dan password
    $query = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {
        $_SESSION['login'] = $username;
        header("location:dashboard.php");
        exit;
    } else {
        $error = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Safana Kasir</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { 
            background-color: #0d2240; 
            min-height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            padding: 20px;
        }

        .login-card {
            background: white;
            width: 100%;
            max-width: 400px;
            padding: 35px 30px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .login-card .icon {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        .login-card h2 {
            color: #0d2240;
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .login-card p {
            color: #64748b;
            font-size: 0.85rem;
            margin-bottom: 25px;
        }

        /* Message Error Alert */
        .alert-error {
            background: #fee2e2;
            color: #ef4444;
            padding: 12px;
            border-radius: 10px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 20px;
            border: 1px solid #fca5a5;
        }

        .form-group {
            text-align: left;
            margin-bottom: 18px;
        }

        label {
            font-size: 0.75rem;
            font-weight: 700;
            color: #475569;
            text-transform: uppercase;
            display: block;
            margin-bottom: 6px;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 0.95rem;
            outline: none;
            background: #f8fafc;
            transition: border-color 0.2s;
        }

        input:focus {
            border-color: #0d2240;
            background: #fff;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: #ffc107;
            color: #0d2240;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            margin-top: 10px;
            box-shadow: 0 4px 10px rgba(255, 193, 7, 0.3);
            transition: background 0.2s;
        }

        .btn-login:hover {
            background: #e0a800;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="icon">🛒</div>
        <h2>LOGIN KASIR</h2>
        <p>Silakan masuk untuk mengakses sistem</p>

        <!-- Tampilkan Pesan Error Jika Login Gagal -->
        <?php if (!empty($error)) { ?>
            <div class="alert-error">
                <?=$error?>
            </div>
        <?php } ?>

        <form method="post">
            <div class="form-group">
                <label>Username</label>
                <input name="username" type="text" placeholder="Masukkan username" required autofocus>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input name="password" type="password" placeholder="Masukkan password" required>
            </div>

            <button name="login" type="submit" class="btn-login">Masuk Sekarang</button>
        </form>
    </div>

</body>
</html>