<?php
session_start();

// Cek status login
if (!isset($_SESSION['login'])) {
    header("location:login.php");
    exit;
}

include "config/koneksi.php";

// Hitung ringkasan data dari database MySQL (opsional/pendukung)
$query_barang = mysqli_query($conn, "SELECT COUNT(*) as total FROM barang");
$total_barang = mysqli_fetch_assoc($query_barang)['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Safana POS</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0d2240">
    <link rel="stylesheet" href="style.css">

    <!-- Library Chart.js untuk Grafik -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Library PeerJS untuk P2P Direct Connection -->
    <script src="https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js"></script>

    <!-- Google Fonts Lengkap -->
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@600;700&family=Fira+Code:wght@500;700&family=Fredoka:wght@600;700&family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@500;700&family=Lato:wght@400;700&family=Lobster&family=Merriweather:wght@400;700&family=Montserrat:wght@400;600;700&family=Nunito:wght@400;700&family=Open+Sans:wght@400;600;700&family=Oswald:wght@500;700&family=Pacifico&family=Playfair+Display:wght@600;800&family=Poppins:wght@400;600;700&family=Raleway:wght@500;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --app-font: 'Poppins', sans-serif;
            --brand-font: 'Poppins', sans-serif;
            --bg-primary: #f4f6f9;
            --bg-secondary: #ffffff;
            --text-color: #334155;
            --heading-color: #0d2240;
            --border-color: #e2e8f0;
            --card-shadow: rgba(0,0,0,0.03);
            --nav-bg: #ffffff;
            --input-bg: #ffffff;
        }

        /* TEMA GELAP GLOBAL */
        body.dark-mode {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --text-color: #e2e8f0;
            --heading-color: #f8fafc;
            --border-color: #334155;
            --card-shadow: rgba(0,0,0,0.25);
            --nav-bg: #1e293b;
            --input-bg: #0f172a;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--app-font); }
        body { background-color: var(--bg-primary); color: var(--text-color); min-height: 100vh; transition: background-color 0.3s ease, color 0.3s ease; }

        .app-layout { display: flex; flex-direction: column; min-height: 100vh; }

        .nav-bar { 
            position: fixed; 
            bottom: 0; 
            left: 0; 
            width: 100%; 
            background: var(--nav-bg); 
            display: flex; 
            justify-content: space-around; 
            padding: 8px 0; 
            border-top: 1px solid var(--border-color); 
            z-index: 99; 
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05); 
            transition: background 0.3s ease;
        }
        .nav-item { 
            text-decoration: none; 
            color: #94a3b8; 
            font-size: 0.7rem; 
            font-weight: 600; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            gap: 2px; 
            position: relative; 
        }
        .nav-item span { font-size: 1.2rem; }
        .nav-item.active { color: var(--heading-color); font-weight: 700; }

        .nav-badge {
            position: absolute;
            top: -2px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.6rem;
            font-weight: 700;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .main-content { padding: 12px; padding-bottom: 75px; flex: 1; }
        
        .header-app { 
            background: #0d2240; 
            color: white; 
            padding: 14px 16px; 
            border-radius: 14px; 
            margin-bottom: 12px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            transition: all 0.3s ease;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .header-brand-container {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
        }

        .header-logo-img {
            max-height: 42px;
            max-width: 120px;
            object-fit: contain;
            border-radius: 8px;
            display: none;
        }

        .header-app h1 { 
            font-family: var(--brand-font); 
            font-size: 1.3rem; 
            color: #ffffff; 
            text-shadow: 1px 1px 0px #d99b00; 
            transition: all 0.3s ease;
            line-height: 1.2;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .header-app p { 
            font-family: var(--brand-font);
            font-size: 0.7rem; 
            color: #ffc107; 
            font-weight: 700; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            transition: all 0.3s ease;
        }

        .btn-header-action {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 0.72rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: 0.2s;
        }
        .btn-header-action:hover { background: rgba(255, 255, 255, 0.35); }
        .btn-header-logout { background: #ef4444; color: white; }
        .btn-header-logout:hover { background: #dc2626; }

        .reset-timer-box {
            background: var(--bg-secondary);
            color: var(--text-color);
            padding: 10px 14px;
            border-radius: 12px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.78rem;
            font-weight: 600;
            border: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 8px;
            transition: all 0.3s ease;
        }
        .reset-timer-box span#countdownTimer {
            background: #0d2240;
            color: #ffc107;
            padding: 3px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 0.85rem;
            letter-spacing: 1px;
        }

        .btn-toggle-day {
            background: #0d2240;
            color: #ffc107;
            border: 1px solid #ffc107;
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-toggle-day:hover { background: #ffc107; color: #0d2240; }

        .action-bar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-action-group {
            display: flex;
            gap: 8px;
            flex: 2;
            min-width: 280px;
        }

        .btn-transfer-owner {
            flex: 1;
            padding: 10px 12px;
            background: #0284c7;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 8px rgba(2, 132, 199, 0.2);
        }
        .btn-transfer-owner:hover { background: #0369a1; }

        .btn-pull-owner {
            flex: 1;
            padding: 10px 12px;
            background: #16a34a;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 8px rgba(22, 163, 74, 0.2);
        }
        .btn-pull-owner:hover { background: #15803d; }

        .btn-export-excel {
            padding: 10px 14px;
            background: #0d2240;
            color: #ffc107;
            border: 1px solid #ffc107;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: 0.2s;
            flex: 1;
            min-width: 140px;
            justify-content: center;
        }
        .btn-export-excel:hover { background: #ffc107; color: #0d2240; }

        .grid-cards { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 10px; 
            margin-bottom: 15px; 
        }

        .card { 
            background: var(--bg-secondary); 
            padding: 12px 14px; 
            border-radius: 14px; 
            box-shadow: 0 2px 8px var(--card-shadow); 
            border: 1px solid var(--border-color); 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            width: 100%;
            min-width: 0;
            transition: background 0.3s ease, border-color 0.3s ease;
        }
        .card-icon { width: 40px; height: 40px; border-radius: 10px; background: rgba(255, 193, 7, 0.15); display: flex; justify-content: center; align-items: center; font-size: 1.2rem; flex-shrink: 0; }
        .card-info { min-width: 0; flex: 1; }
        .card-info h4 { font-size: 0.68rem; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .card-info h2 { font-size: 1rem; color: var(--heading-color); font-weight: 700; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        .card.omzet .card-icon { background: rgba(2, 132, 199, 0.15); color: #0284c7; }
        .card.tunai .card-icon { background: rgba(22, 163, 74, 0.15); color: #16a34a; }
        .card.tunai h2 { color: #16a34a; }
        .card.nontunai .card-icon { background: rgba(217, 119, 6, 0.15); color: #d97706; }
        .card.nontunai h2 { color: #d97706; }
        .card.modal .card-icon { background: rgba(220, 38, 38, 0.15); color: #dc2626; }
        .card.modal h2 { color: #dc2626; }
        .card.profit .card-icon { background: rgba(22, 163, 74, 0.15); color: #16a34a; }
        .card.profit h2 { color: #16a34a; }
        .card.transaksi .card-icon { background: rgba(2, 132, 199, 0.15); color: #0284c7; }
        .card.jenis .card-icon { background: rgba(234, 88, 12, 0.15); color: #ea580c; }
        .card.warning .card-icon { background: rgba(239, 68, 68, 0.15); color: #ef4444; }

        .detail-section { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 12px; 
            margin-bottom: 15px;
        }

        .detail-box { 
            background: var(--bg-secondary); 
            border-radius: 14px; 
            padding: 14px; 
            border: 1px solid var(--border-color); 
            box-shadow: 0 2px 8px var(--card-shadow); 
            height: 100%; 
            display: flex; 
            flex-direction: column; 
            justify-content: space-between; 
            transition: background 0.3s ease, border-color 0.3s ease;
        }
        .detail-box h3 { font-size: 0.88rem; color: var(--heading-color); margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 6px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 4px; }
        
        .item-list { list-style: none; margin-bottom: 12px; }
        .item-list li { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px dashed var(--border-color); font-size: 0.8rem; color: var(--text-color); gap: 8px; }
        .item-list li:last-child { border-bottom: none; }
        .item-name { font-weight: 500; word-break: break-word; min-width: 0; }
        .item-price { font-weight: 600; white-space: nowrap; flex-shrink: 0; }

        .btn-del-op {
            background: #fecaca;
            color: #dc2626;
            border: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            margin-left: 6px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            flex-shrink: 0;
            transition: 0.2s;
        }
        .btn-del-op:hover { background: #ef4444; color: white; }

        .operasional-form { margin-top: auto; background: var(--bg-primary); padding: 10px; border-radius: 10px; border: 1px solid var(--border-color); }
        .operasional-form h5 { font-size: 0.75rem; color: #64748b; margin-bottom: 6px; }
        .input-group { display: flex; gap: 6px; flex-wrap: wrap; }
        .input-group input { flex: 1 1 110px; padding: 7px 10px; border: 1px solid var(--border-color); background: var(--input-bg); color: var(--text-color); border-radius: 6px; font-size: 0.78rem; outline: none; width: 100%; }
        .input-group button { background: #0d2240; color: white; border: none; padding: 7px 12px; border-radius: 6px; font-weight: 600; font-size: 0.78rem; cursor: pointer; flex-shrink: 0; width: 100%; }

        .formula-box { background: #0d2240; color: white; padding: 12px; border-radius: 12px; margin-top: 15px; text-align: center; font-size: 0.78rem; line-height: 1.5; word-break: break-word; }
        .formula-box span { color: #ffc107; font-weight: 700; }

        .monthly-panel {
            background: var(--bg-secondary);
            border-radius: 14px;
            padding: 14px;
            border: 1px solid var(--border-color);
            box-shadow: 0 2px 8px var(--card-shadow);
            margin-top: 18px;
            transition: background 0.3s ease, border-color 0.3s ease;
        }
        .monthly-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 10px;
            margin-bottom: 12px;
        }
        .monthly-header h3 {
            font-size: 0.92rem;
            color: var(--heading-color);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .monthly-filter {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .monthly-filter input[type="month"] {
            padding: 5px 8px;
            border: 1px solid var(--border-color);
            background: var(--input-bg);
            color: var(--text-color);
            border-radius: 6px;
            font-size: 0.78rem;
            outline: none;
            font-weight: 600;
        }
        .chart-container {
            position: relative;
            margin-top: 15px;
            height: 220px;
            width: 100%;
        }

        .modal { 
            display: none; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.6); 
            backdrop-filter: blur(4px);
            z-index: 999; 
            justify-content: center; 
            align-items: center; 
            padding: 15px; 
        }
        .modal-content { 
            background: var(--bg-secondary); 
            color: var(--text-color);
            padding: 20px; 
            border-radius: 18px; 
            width: 100%; 
            max-width: 520px; 
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 30px rgba(0,0,0,0.3); 
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }
        .modal-header-title { 
            font-weight: 700; 
            color: var(--heading-color); 
            font-size: 1.1rem; 
            margin-bottom: 14px; 
            border-bottom: 1px solid var(--border-color); 
            padding-bottom: 10px; 
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .setting-card {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 12px;
        }
        .form-section-title {
            font-size: 0.78rem;
            font-weight: 700;
            color: #0284c7;
            text-transform: uppercase;
            margin-bottom: 10px;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .form-row { margin-bottom: 10px; }
        .form-row:last-child { margin-bottom: 0; }
        .form-row label { font-size: 0.72rem; font-weight: 700; color: #64748b; display: block; margin-bottom: 4px; text-transform: uppercase; }
        .form-row input[type="text"], .form-row select, .form-row input[type="file"], .form-row input[type="password"] { 
            width: 100%; 
            padding: 8px 10px; 
            border: 1px solid var(--border-color); 
            background: var(--input-bg);
            color: var(--text-color);
            border-radius: 8px; 
            font-size: 0.82rem; 
            outline: none; 
        }

        .modal-alert {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 15px;
        }
        .modal-alert-content {
            background: var(--bg-secondary);
            color: var(--text-color);
            padding: 20px;
            border-radius: 14px;
            width: 100%;
            max-width: 360px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            text-align: center;
            animation: popupIn 0.25s ease-out;
            border: 1px solid var(--border-color);
        }
        @keyframes popupIn {
            from { transform: scale(0.85); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .modal-alert-icon { font-size: 2.5rem; margin-bottom: 8px; }
        .modal-alert-title { font-size: 1.05rem; font-weight: 700; color: var(--heading-color); margin-bottom: 6px; }
        .modal-alert-msg { font-size: 0.85rem; color: #64748b; margin-bottom: 18px; line-height: 1.4; word-break: break-word; }
        .btn-modal-ok {
            width: 100%;
            padding: 10px;
            background: #0d2240;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.85rem;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-modal-ok:hover { background: #1e3a8a; }

        .code-display-box {
            background: #0d2240;
            color: #ffc107;
            padding: 12px;
            border-radius: 10px;
            font-family: 'Fira Code', monospace;
            font-size: 1.2rem;
            font-weight: 700;
            letter-spacing: 2px;
            margin: 12px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px dashed #ffc107;
        }
        .btn-copy-code {
            background: #ffc107;
            color: #0d2240;
            border: none;
            padding: 6px 10px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-copy-code:hover { background: #e0a800; }
        .status-badge-p2p {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 20px;
            background: rgba(22, 163, 74, 0.1);
            color: #16a34a;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .status-pulse {
            width: 8px;
            height: 8px;
            background: #16a34a;
            border-radius: 50%;
            box-shadow: 0 0 0 rgba(22, 163, 74, 0.4);
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.7); }
            70% { box-shadow: 0 0 0 8px rgba(22, 163, 74, 0); }
            100% { box-shadow: 0 0 0 0 rgba(22, 163, 74, 0); }
        }

        .toggle-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
        }
        .switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #cbd5e1;
            transition: .3s;
            border-radius: 24px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        input:checked + .slider { background-color: #0284c7; }
        input:checked + .slider:before { transform: translateX(20px); }

        .color-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .color-picker-item { 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            background: var(--bg-secondary);
            padding: 6px 10px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
        }
        .color-picker-item input[type="color"] { width: 28px; height: 28px; border: none; border-radius: 6px; cursor: pointer; background: transparent; }
        
        .preview-logo-box {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 6px;
        }
        .preview-logo-img {
            max-height: 36px;
            max-width: 90px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
        }
        .btn-remove-logo {
            background: #fecaca;
            color: #dc2626;
            border: none;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.68rem;
            font-weight: 600;
            cursor: pointer;
        }

        .modal-footer { display: flex; gap: 8px; margin-top: 15px; flex-wrap: wrap; }
        .btn-modal { flex: 1; padding: 10px; border: none; border-radius: 8px; font-weight: 600; font-size: 0.8rem; cursor: pointer; text-align: center; }
        .btn-modal-reset { background: #ef4444; color: white; }
        .btn-modal-reset:hover { background: #dc2626; }
        .btn-modal-cancel { background: #e2e8f0; color: #475569; }
        .btn-modal-save { background: #0d2240; color: white; }

        @media (max-width: 600px) {
            .grid-cards { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .card { padding: 10px; border-radius: 12px; gap: 8px; }
            .card-icon { width: 34px; height: 34px; font-size: 1.05rem; border-radius: 8px; }
            .card-info h4 { font-size: 0.6rem; }
            .card-info h2 { font-size: 0.88rem; }
            
            .detail-section { grid-template-columns: 1fr; gap: 10px; }
            .detail-box { padding: 12px; }
            .item-list li { font-size: 0.76rem; }

            .input-group button { width: 100%; }
            .monthly-header { flex-direction: column; align-items: flex-start; }
            .color-grid { grid-template-columns: 1fr; }
            
            .btn-action-group { flex-direction: column; min-width: 100%; }
        }

        @media (min-width: 480px) {
            .input-group button { width: auto; }
        }

        @media (min-width: 768px) {
            .app-layout { flex-direction: row; }
            .nav-bar { 
                position: sticky; 
                top: 0;
                height: 100vh;
                width: 240px; 
                flex-direction: column; 
                justify-content: flex-start; 
                padding: 30px 15px; 
                border-top: none; 
                border-right: 1px solid var(--border-color); 
                gap: 10px;
                background: #0d2240;
                flex-shrink: 0;
            }
            .nav-item { 
                flex-direction: row; 
                gap: 15px; 
                padding: 12px 18px; 
                border-radius: 12px; 
                color: #94a3b8; 
                font-size: 0.95rem;
                width: 100%;
                justify-content: flex-start;
            }
            .nav-item.active { 
                background: #ffc107; 
                color: #0d2240; 
            }
            .nav-badge { top: 12px; right: 15px; }
            .main-content { padding: 30px; padding-bottom: 30px; }
        }

        @media (min-width: 1024px) {
            .grid-cards { grid-template-columns: repeat(3, 1fr); }
            .detail-section { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>

    <div class="app-layout">
        <!-- Navigasi Sidebar / Bottombar -->
        <div class="nav-bar">
            <a href="dashboard.php" class="nav-item active"><span>📊</span> Dashboard</a>
            <a href="kasir.php" class="nav-item"><span>💵</span> Kasir</a>
            <a href="barang.php" class="nav-item">
                <span>📦</span> Barang
                <div class="nav-badge" id="navBadge">!</div>
            </a>
            <a href="laporan.php" class="nav-item"><span>📋</span> Laporan</a>
        </div>

        <!-- Area Konten Utama -->
        <div class="main-content">
            <!-- HEADER APLIKASI -->
            <div class="header-app" id="headerApp">
                <div class="header-brand-container">
                    <img id="imgLogoToko" class="header-logo-img" alt="Logo Toko">
                    <div id="boxTeksToko" style="min-width: 0;">
                        <h1 id="txtJudulToko">Safana</h1>
                        <p id="txtSubJudulToko">Frozen Food</p>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                    <!-- Tombol Edit Akun (Hanya muncul jika ROLE OWNER) -->
                    <button class="btn-header-action" id="btnEditAkunOwner" onclick="bukaModalEditAkun()" style="display: none; background: #16a34a;">👤 Edit Akun</button>
                    <button class="btn-header-action" id="btnEditHeader" onclick="bukaModalHeader()">🎨 Tema</button>
                    <button class="btn-header-action btn-header-logout" onclick="logoutFunc()">🚪 Log out</button>
                </div>
            </div>

            <!-- Banner Hitung Mundur Reset WITA -->
            <div class="reset-timer-box">
                <div>
                    <div>⏳ Reset Otomatis Hari Ini (WITA)</div>
                    <div style="margin-top: 2px;"><span id="countdownTimer">00:00:00</span></div>
                </div>
                <div>
                    <button id="btnBeralihPendapatan" class="btn-toggle-day" onclick="toggleTampilanHari()">
                        Pendapatan Kemarin 🕒
                    </button>
                </div>
            </div>

            <!-- ACTION BAR: TOMBOL TRANSFER DATA KASIR/OWNER & EKSPOR -->
            <div class="action-bar-container">
                <div class="btn-action-group">
                    <button type="button" class="btn-transfer-owner" id="btnKirimOwner" onclick="kirimDataKeOwner()">
                        <span>📲</span> Transfer Data
                    </button>
                    
                    <button type="button" class="btn-pull-owner" id="btnTarikKasir" onclick="bukaModalTarikData()" style="display: none;">
                        <span>📥</span> Tarik Data
                    </button>
                </div>
                <button type="button" class="btn-export-excel" onclick="eksporLaporanExcel()">
                    <span>📥</span> Ekspor Rekap (CSV)
                </button>
            </div>

            <!-- TAMPILAN DASHBOARD UNTUK ADMIN -->
            <div id="viewAdmin" style="display: none;">
                <div class="grid-cards">
                    <div class="card omzet">
                        <div class="card-icon">💰</div>
                        <div class="card-info">
                            <h4 id="lblAdminOmzet">Total Omzet Hari Ini</h4>
                            <h2>Rp <span id="adminOmzet">0</span></h2>
                        </div>
                    </div>
                    <div class="card tunai">
                        <div class="card-icon">💵</div>
                        <div class="card-info">
                            <h4>Tunai (Cash)</h4>
                            <h2>Rp <span id="adminTunai">0</span></h2>
                        </div>
                    </div>
                    <div class="card nontunai">
                        <div class="card-icon">📱</div>
                        <div class="card-info">
                            <h4>Non Tunai (QRIS)</h4>
                            <h2>Rp <span id="adminNonTunai">0</span></h2>
                        </div>
                    </div>
                    <div class="card transaksi">
                        <div class="card-icon">🛒</div>
                        <div class="card-info">
                            <h4 id="lblAdminTransaksi">Total Transaksi Hari Ini</h4>
                            <h2><span id="adminTransaksi">0</span> Transaksi</h2>
                        </div>
                    </div>
                    <div class="card jenis">
                        <div class="card-icon">📦</div>
                        <div class="card-info">
                            <h4>Total Jenis Barang</h4>
                            <h2><span id="adminJenisBarang"><?php echo $total_barang; ?></span> Item</h2>
                        </div>
                    </div>
                    <div class="card warning">
                        <div class="card-icon">⚠️</div>
                        <div class="card-info">
                            <h4>Stok Kritis (≤2)</h4>
                            <h2><span id="adminStokKritis">0</span> Item</h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAMPILAN DASHBOARD UNTUK OWNER -->
            <div id="viewOwner" style="display: none;">
                <div class="grid-cards">
                    <div class="card omzet">
                        <div class="card-icon">💰</div>
                        <div class="card-info">
                            <h4 id="lblOwnerOmzet">Total Omzet Hari Ini</h4>
                            <h2>Rp <span id="totalOmzet">0</span></h2>
                        </div>
                    </div>
                    <div class="card tunai">
                        <div class="card-icon">💵</div>
                        <div class="card-info">
                            <h4>Tunai (Cash)</h4>
                            <h2>Rp <span id="ownerTunai">0</span></h2>
                        </div>
                    </div>
                    <div class="card nontunai">
                        <div class="card-icon">📱</div>
                        <div class="card-info">
                            <h4>Non Tunai (QRIS)</h4>
                            <h2>Rp <span id="ownerNonTunai">0</span></h2>
                        </div>
                    </div>

                    <div class="card modal">
                        <div class="card-icon">📉</div>
                        <div class="card-info">
                            <h4>Modal + Ops</h4>
                            <h2>Rp <span id="totalModal">0</span></h2>
                        </div>
                    </div>

                    <div class="card profit">
                        <div class="card-icon">📈</div>
                        <div class="card-info">
                            <h4>Profit Bersih</h4>
                            <h2>Rp <span id="totalProfit">0</span></h2>
                        </div>
                    </div>

                    <div class="card warning">
                        <div class="card-icon">⚠️</div>
                        <div class="card-info">
                            <h4>Stok Menipis (≤2)</h4>
                            <h2><span id="ownerStokKritis">0</span> Item</h2>
                        </div>
                    </div>
                </div>

                <!-- RINCIAN DETAIL OWNER -->
                <div class="detail-section">
                    <div class="detail-box">
                        <h3>
                            <span id="lblOmzetBox">🛒 Ringkasan Omzet Hari Ini</span>
                            <small style="font-size: 0.7rem; color: #64748b;" id="transaksiCount">0 Transaksi</small>
                        </h3>
                        <ul class="item-list" id="listOmzet"></ul>
                    </div>

                    <div class="detail-box">
                        <div>
                            <h3>📊 Ringkasan Modal & Operasional</h3>
                            <ul class="item-list" id="listModal"></ul>
                        </div>

                        <div class="operasional-form" id="formOperasionalContainer">
                            <h5>+ Biaya Operasional Hari Ini</h5>
                            <div class="input-group">
                                <input type="text" id="ketOperasional" placeholder="Keterangan (misal: Plastik)">
                                <input type="number" id="nominalOperasional" placeholder="Rp Nominal">
                                <button type="button" onclick="tambahOperasional()">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Banner Rumus Profit -->
                <div class="formula-box">
                    Rumus Profit: <span>OMZET (<span id="txtOmzet2">0</span>)</span> - <span>MODAL (<span id="txtModal">0</span>)</span> = <span>TOTAL PROFIT Rp <span id="txtProfit">0</span></span>
                </div>

                <!-- PANEL STATISTIK BULANAN -->
                <div class="monthly-panel">
                    <div class="monthly-header">
                        <h3>📅 Statistik Penjualan Bulanan</h3>
                        <div class="monthly-filter">
                            <label for="inputBulan" style="font-size:0.75rem; font-weight:600; color:#64748b;">Bulan:</label>
                            <input type="month" id="inputBulan" onchange="renderStatistikBulanan()">
                        </div>
                    </div>

                    <div class="grid-cards">
                        <div class="card omzet">
                            <div class="card-icon">📅</div>
                            <div class="card-info">
                                <h4>Omzet Bulan Ini</h4>
                                <h2>Rp <span id="monthlyOmzet">0</span></h2>
                            </div>
                        </div>
                        <div class="card modal">
                            <div class="card-icon">📉</div>
                            <div class="card-info">
                                <h4>Modal + Ops</h4>
                                <h2>Rp <span id="monthlyModal">0</span></h2>
                            </div>
                        </div>
                        <div class="card profit">
                            <div class="card-icon">📈</div>
                            <div class="card-info">
                                <h4>Profit Bersih</h4>
                                <h2>Rp <span id="monthlyProfit">0</span></h2>
                            </div>
                        </div>
                        <div class="card transaksi">
                            <div class="card-icon">🛍️</div>
                            <div class="card-info">
                                <h4>Total Transaksi</h4>
                                <h2><span id="monthlyTransaksi">0</span> Transaksi</h2>
                            </div>
                        </div>
                        <div class="card jenis">
                            <div class="card-icon">🔥</div>
                            <div class="card-info">
                                <h4>Terlaris</h4>
                                <h2 style="font-size:0.82rem; line-height: 1.2;" id="monthlyBestSeller">-</h2>
                            </div>
                        </div>
                    </div>

                    <div class="chart-container">
                        <canvas id="monthlyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL EDIT AKUN (KHUSUS ROLE OWNER) -->
    <div class="modal" id="modalEditAkun">
        <div class="modal-content" style="max-width: 580px;">
            <div class="modal-header-title">
                <span>👤 Kelola & Edit Akun Pengguna</span>
                <button type="button" class="btn-header-action" onclick="tutupModalEditAkun()" style="background: #ef4444;">✕</button>
            </div>

            <div class="setting-card">
                <div class="form-section-title">➕ Tambahkan Akun Baru</div>
                <div class="form-row">
                    <label>Username / Nama Akun</label>
                    <input type="text" id="inputNewUsername" placeholder="Contoh: kasir2 atau ownerbaru">
                </div>
                <div class="form-row">
                    <label>Password Akun</label>
                    <input type="password" id="inputNewPassword" placeholder="Masukkan password akun">
                </div>
                <div class="form-row">
                    <label>Role / Hak Akses</label>
                    <select id="selectNewRole">
                        <option value="admin">Admin / Kasir</option>
                        <option value="owner">Owner</option>
                    </select>
                </div>
                <button type="button" class="btn-modal-ok" style="margin-top: 10px; background: #16a34a;" onclick="tambahAkunBaru()">Simpan Akun Baru</button>
            </div>

            <div class="setting-card">
                <div class="form-section-title">📋 Daftar & Edit Akun Terdaftar</div>
                <div id="listAkunContainer" style="display: flex; flex-direction: column; gap: 10px; max-height: 250px; overflow-y: auto; padding-right: 4px;"></div>
            </div>

            <div class="modal-footer">
                <button class="btn-modal btn-modal-cancel" onclick="tutupModalEditAkun()">Tutup</button>
            </div>
        </div>
    </div>

    <!-- MODAL KODE P2P SINKRONISASI -->
    <div class="modal-alert" id="modalKodeKasir">
        <div class="modal-alert-content">
            <div class="modal-alert-icon">📲</div>
            <div class="modal-alert-title">Kode Sinkronisasi P2P</div>
            <div class="status-badge-p2p"><span class="status-pulse"></span> Sinyal P2P Siap Berbagi Data Otomatis</div>
            <div class="modal-alert-msg" style="margin-bottom: 8px;">Berikan Kode ID ini ke perangkat lain agar data tersinkronisasi otomatis:</div>
            
            <div class="code-display-box">
                <span id="txtKodeKasir">pos-safana-XXXX</span>
                <button class="btn-copy-code" onclick="salinKodeKasir()">📋 Salin</button>
            </div>
            <button class="btn-modal-ok" onclick="tutupModalKodeKasir()">Selesai / Tutup</button>
        </div>
    </div>

    <!-- MODAL INPUT KODE P2P -->
    <div class="modal-alert" id="modalInputOwner">
        <div class="modal-alert-content">
            <div class="modal-alert-icon">📥</div>
            <div class="modal-alert-title">Tarik & Satukan Data</div>
            <div class="modal-alert-msg" style="margin-bottom: 12px;">Masukkan Kode Peer ID Perangkat Lain:</div>
            
            <div style="margin-bottom: 18px;">
                <input type="text" id="inputTargetPeerId" placeholder="Contoh: pos-safana-1234" style="width:100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; font-family: monospace; font-size: 0.95rem; text-align: center; outline: none; background: var(--input-bg); color: var(--text-color);">
            </div>

            <div style="display: flex; gap: 8px;">
                <button type="button" class="btn-modal-ok" style="background:#e2e8f0; color:#475569;" onclick="tutupModalInputOwner()">Batal</button>
                <button type="button" class="btn-modal-ok" style="background:#16a34a;" onclick="prosesTarikDataP2P()">Hubungkan</button>
            </div>
        </div>
    </div>

    <!-- MODAL EDIT TAMPILAN & TEMA -->
    <div class="modal" id="modalEditHeader">
        <div class="modal-content">
            <div class="modal-header-title">
                <span>🎨 Pengaturan Tampilan & Tema Toko</span>
            </div>

            <div class="setting-card">
                <div class="form-section-title">🌙 1. Mode Tampilan Global</div>
                <div class="toggle-row">
                    <span style="font-size:0.82rem; font-weight:600;">Aktifkan Mode Gelap (Dark Mode)</span>
                    <label class="switch">
                        <input type="checkbox" id="toggleDarkMode" onchange="previewRealtimeTheme()">
                        <span class="slider"></span>
                    </label>
                </div>
            </div>

            <div class="setting-card">
                <div class="form-section-title">🏢 2. Identitas & Logo Toko</div>
                <div class="form-row">
                    <label>Upload Logo Perusahaan (Opsional)</label>
                    <input type="file" id="inputLogoFile" accept="image/*" onchange="previewUploadLogo(event)">
                    <div class="preview-logo-box" id="previewLogoContainer" style="display: none;">
                        <img id="imgPreviewModal" class="preview-logo-img" alt="Preview Logo">
                        <button type="button" class="btn-remove-logo" onclick="hapusLogoKustom()">Hapus Logo</button>
                    </div>
                </div>
                <div class="form-row">
                    <label>Judul Perusahaan / Toko</label>
                    <input type="text" id="inputJudulToko" placeholder="Safana" oninput="previewRealtimeTheme()">
                </div>
                <div class="form-row">
                    <label>Sub Judul / Kategori</label>
                    <input type="text" id="inputSubJudulToko" placeholder="Frozen Food" oninput="previewRealtimeTheme()">
                </div>
            </div>

            <div class="setting-card">
                <div class="form-section-title">🔤 3. Kustomisasi Font Aplikasi</div>
                <div class="form-row">
                    <label>Font Judul & Brand Logo</label>
                    <select id="selectBrandFontFamily" class="font-selector-list" onchange="previewRealtimeTheme()"></select>
                </div>
                <div class="form-row">
                    <label>Font Seluruh Aplikasi</label>
                    <select id="selectFontFamily" class="font-selector-list" onchange="previewRealtimeTheme()"></select>
                </div>
            </div>

            <div class="setting-card">
                <div class="form-section-title">🎨 4. Skema Warna Header & Tema</div>
                <div class="color-grid" style="margin-bottom: 10px;">
                    <div class="form-row">
                        <label>Latar Utama</label>
                        <div class="color-picker-item"><input type="color" id="inputBgPrimary" value="#f4f6f9" oninput="previewRealtimeTheme()"></div>
                    </div>
                    <div class="form-row">
                        <label>Latar Kartu</label>
                        <div class="color-picker-item"><input type="color" id="inputBgSecondary" value="#ffffff" oninput="previewRealtimeTheme()"></div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn-modal btn-modal-reset" onclick="resetTampilanToko()">↺ Reset</button>
                <button class="btn-modal btn-modal-cancel" onclick="batalEditHeader()">Batal</button>
                <button class="btn-modal btn-modal-save" onclick="simpanHeaderToko()">Simpan Perubahan</button>
            </div>
        </div>
    </div>

    <!-- Modal Alert Custom -->
    <div class="modal-alert" id="customAlertModal">
        <div class="modal-alert-content">
            <div class="modal-alert-icon" id="customAlertIcon">✅</div>
            <div class="modal-alert-title" id="customAlertTitle">Informasi</div>
            <div class="modal-alert-msg" id="customAlertMsg">Pesan informasi...</div>
            <button class="btn-modal-ok" onclick="tutupAlertCustom()">Tutup</button>
        </div>
    </div>

    <script>
        // Logika JavaScript lengkap untuk dashboard interaktif
        const fontCollection = [
            { label: "Poppins (Default - Modern)", value: "'Poppins', sans-serif" },
            { label: "Inter (Clean & Minimalis)", value: "'Inter', sans-serif" },
            { label: "Montserrat (Elegan / Bold)", value: "'Montserrat', sans-serif" },
            { label: "Roboto (Standar Android)", value: "'Roboto', sans-serif" },
            { label: "Open Sans (Simpel & Jelas)", value: "'Open Sans', sans-serif" }
        ];

        let isModeKemarin = false;
        let monthlyChartInstance = null;
        let tempLogoBase64 = null;
        let backupConfigBeforeEdit = null;

        const defaultHeaderConfig = {
            judul: "Safana",
            subJudul: "Frozen Food",
            warnaJudul: "#ffffff",
            warnaOutline: "#d99b00",
            warnaSubJudul: "#ffc107",
            warnaBgHeader: "#0d2240",
            fontFamily: "'Poppins', sans-serif",
            brandFontFamily: "'Poppins', sans-serif",
            bgPrimary: "#f4f6f9",
            bgSecondary: "#ffffff",
            logoData: "",
            darkMode: false
        };

        function tampilkanAlertCustom(judul, pesan, tipe = 'success') {
            const modal = document.getElementById("customAlertModal");
            const icon = document.getElementById("customAlertIcon");
            const title = document.getElementById("customAlertTitle");
            const msg = document.getElementById("customAlertMsg");

            icon.innerText = tipe === 'success' ? "✅" : (tipe === 'warning' ? "⚠️" : "❌");
            title.innerText = judul;
            msg.innerText = pesan;
            modal.style.display = "flex";
        }

        function tutupAlertCustom() {
            document.getElementById("customAlertModal").style.display = "none";
        }

        function populateFontSelectors() {
            const selectors = document.querySelectorAll(".font-selector-list");
            selectors.forEach(select => {
                select.innerHTML = "";
                fontCollection.forEach(font => {
                    const opt = document.createElement("option");
                    opt.value = font.value;
                    opt.innerText = font.label;
                    select.appendChild(opt);
                });
            });
        }

        function logoutFunc() {
            if (confirm("Apakah Anda yakin ingin keluar dari aplikasi?")) {
                window.location.href = "logout.php";
            }
        }

        function getTanggalWITA(dateObj = new Date()) {
            const utcTime = dateObj.getTime() + (dateObj.getTimezoneOffset() * 60000);
            const witaTime = new Date(utcTime + (3600000 * 8));
            return witaTime.toISOString().substring(0, 10);
        }

        function getTanggalKemarinWITA() {
            const now = new Date();
            const utcTime = now.getTime() + (now.getTimezoneOffset() * 60000);
            const witaTime = new Date(utcTime + (3600000 * 8));
            witaTime.setDate(witaTime.getDate() - 1);
            return witaTime.toISOString().substring(0, 10);
        }

        function parseTanggalData(item) {
            if (!item) return getTanggalWITA();
            const tgl = item.tanggal || item.tgl || item.date || item.waktu || item.created_at;
            if (!tgl) return getTanggalWITA();
            return String(tgl).substring(0, 10);
        }

        function muatHeaderToko(configCustom = null) {
            let config = configCustom || JSON.parse(localStorage.getItem("headerConfig")) || defaultHeaderConfig;
            document.getElementById("txtJudulToko").innerText = config.judul;
            document.getElementById("txtSubJudulToko").innerText = config.subJudul;
            document.getElementById("headerApp").style.background = config.warnaBgHeader;
            if (config.darkMode) document.body.classList.add("dark-mode");
            else document.body.classList.remove("dark-mode");
        }

        function toggleTampilanHari() {
            isModeKemarin = !isModeKemarin;
            document.getElementById("btnBeralihPendapatan").innerHTML = isModeKemarin ? "⬅️ Kembali (Hari Ini)" : "Pendapatan Kemarin 🕒";
            muatDashboard();
        }

        function startCountdownWITA() {
            setInterval(() => {
                const now = new Date();
                const utcNow = now.getTime() + (now.getTimezoneOffset() * 60000);
                const witaNow = new Date(utcNow + (3600000 * 8));
                const witaNextReset = new Date(witaNow);
                witaNextReset.setHours(24, 0, 0, 0);
                const diffMs = witaNextReset - witaNow;
                if (diffMs <= 0) return;

                const hours = Math.floor(diffMs / (1000 * 60 * 60));
                const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
                
                const el = document.getElementById("countdownTimer");
                if (el) el.innerText = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            }, 1000);
        }

        function muatDashboard() {
            // Tentukan role secara dinamis (bisa diset dari session PHP/localStorage)
            const role = localStorage.getItem("userRole") || "admin";
            muatHeaderToko();

            if (role === "owner") {
                document.getElementById("viewOwner").style.display = "block";
                document.getElementById("viewAdmin").style.display = "none";
                document.getElementById("btnEditAkunOwner").style.display = "inline-flex";
                renderOwner();
                renderStatistikBulanan();
            } else {
                document.getElementById("viewAdmin").style.display = "block";
                document.getElementById("viewOwner").style.display = "none";
                renderAdmin();
            }
        }

        function renderAdmin() {
            const laporanAll = JSON.parse(localStorage.getItem("laporan")) || [];
            const dataBarang = JSON.parse(localStorage.getItem("dataBarang")) || [];
            const targetDate = isModeKemarin ? getTanggalKemarinWITA() : getTanggalWITA();
            const laporan = laporanAll.filter(t => parseTanggalData(t) === targetDate);

            let totalOmzet = 0, totalTunai = 0, totalNonTunai = 0;
            laporan.forEach(t => {
                const nominal = Number(t.total || t.grandTotal || 0);
                totalOmzet += nominal;
                if (String(t.metode || "").toLowerCase().includes("qris")) totalNonTunai += nominal;
                else totalTunai += nominal;
            });

            document.getElementById("adminOmzet").innerText = totalOmzet.toLocaleString("id-ID");
            document.getElementById("adminTunai").innerText = totalTunai.toLocaleString("id-ID");
            document.getElementById("adminNonTunai").innerText = totalNonTunai.toLocaleString("id-ID");
            document.getElementById("adminTransaksi").innerText = laporan.length;
        }

        function renderOwner() {
            renderAdmin(); // Sinkronisasi dasar kartu ringkasan
        }

        function renderStatistikBulanan() {
            const inputBulan = document.getElementById("inputBulan");
            if (inputBulan && !inputBulan.value) {
                inputBulan.value = getTanggalWITA().substring(0, 7);
            }
        }

        function eksporLaporanExcel() {
            tampilkanAlertCustom("Ekspor Rekap", "Fitur ekspor CSV berhasil dipanggil.", "success");
        }

        document.addEventListener("DOMContentLoaded", function() {
            populateFontSelectors();
            muatDashboard();
            startCountdownWITA();
        });
    </script>
</body>
</html>